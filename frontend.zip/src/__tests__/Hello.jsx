export default function Hello({ name = "mundo" }) {
  return <h1 role="heading">Hola {name}</h1>;
}
